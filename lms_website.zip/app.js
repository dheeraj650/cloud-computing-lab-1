function showMessage(section) {
  alert("Opening " + section + " section...");
}
